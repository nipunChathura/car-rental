package com.example.carrental;

public class CarService {
}
